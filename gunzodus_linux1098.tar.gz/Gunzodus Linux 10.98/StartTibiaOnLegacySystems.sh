#!/bin/bash

# This script starts Tibia with a set of provided libraries.
# (the file libc6/README explains where those libraries came from)

# Please try calling this script instead of calling ./Tibia
# in case of problems while starting Tibia.
# (a typical error this script might help with is the dreaded
# "Floating point exception" right after starting Tibia)

/bin/echo "This script starts Tibia with a set of provided libraries."
/bin/echo
/bin/echo "Please note that you should normally NOT need to call this script,"
/bin/echo "unless you are running a very old version of the GNU/Linux system."
/bin/echo "ONLY try using this script if starting the Tibia executable directly"
/bin/echo "does not work on your system!"
/bin/echo

./libc6/ld-linux.so.2 --library-path ./libc6 ./Tibia
